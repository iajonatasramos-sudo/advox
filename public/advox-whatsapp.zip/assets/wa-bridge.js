let pronto = false;
let WPP;
function emitir(evento, data) {
  window.postMessage({ __advox: "evt", evento, data }, "*");
}
function responder(id, ok, data, erro) {
  window.postMessage({ __advox: "res", id, ok, data, erro }, "*");
}
const telefonePorLid = /* @__PURE__ */ new Map();
function telefoneDoChat(chat, id) {
  if (!chat || id.endsWith("@g.us")) return null;
  if (id.endsWith("@c.us") && chat.id?.user) return String(chat.id.user);
  if (id.endsWith("@lid")) {
    return telefonePorLid.get(id) ?? chat.contact?.phoneNumber?.user ?? chat.phoneNumber?.user ?? null;
  }
  return chat.id?.user ? String(chat.id.user) : null;
}
async function resolverTelefone(id) {
  if (!id.endsWith("@lid")) return null;
  const emCache = telefonePorLid.get(id);
  if (emCache) return emCache;
  try {
    const entrada = await WPP.contact.getPnLidEntry(id);
    const numero = entrada?.phoneNumber?.id ?? entrada?.phoneNumber?._serialized?.split("@")[0];
    const digitos = String(numero ?? "").replace(/\D/g, "");
    if (digitos.length >= 8) {
      telefonePorLid.set(id, digitos);
      return digitos;
    }
  } catch {
  }
  return null;
}
function contatoDoChat(chat) {
  if (!chat) return null;
  const id = chat.id?._serialized ?? String(chat.id ?? "");
  const ehGrupo = !!chat.isGroup || id.endsWith("@g.us");
  const nome = chat.formattedTitle || chat.name || chat.contact?.formattedName || chat.contact?.pushname || "";
  const digitos = ehGrupo ? null : telefoneDoChat(chat, id);
  return { chatId: id, nome, telefone: digitos, ehGrupo };
}
async function contatoCompleto(chat) {
  const base = contatoDoChat(chat);
  if (!base || base.telefone || base.ehGrupo) return base;
  const digitos = await resolverTelefone(base.chatId);
  return digitos ? { ...base, telefone: digitos } : base;
}
const fotosPorId = /* @__PURE__ */ new Map();
const comandos = {
  async ping() {
    let mainReady = false;
    try {
      mainReady = !!WPP?.conn?.isMainReady?.();
    } catch {
    }
    return { pronto, temWPP: !!WPP, mainReady };
  },
  async activeChat() {
    return contatoCompleto(WPP.chat.getActiveChat());
  },
  async listChats() {
    const chats = await WPP.chat.list() ?? [];
    return chats.map((c) => {
      const base = contatoDoChat(c);
      if (!base) return null;
      return { ...base, naoLidas: c.unreadCount ?? 0, ultimaTs: typeof c.t === "number" ? c.t : null };
    }).filter(Boolean);
  },
  async openChat({ chatId }) {
    await WPP.chat.openChatBottom(chatId);
    return { ok: true };
  },
  /** Foto de perfil (cache por id). Sem foto ou sem permissão: null — a UI usa as iniciais. */
  async fotos({ ids }) {
    const saida = {};
    await Promise.all((ids ?? []).slice(0, 60).map(async (id) => {
      if (fotosPorId.has(id)) {
        saida[id] = fotosPorId.get(id) ?? null;
        return;
      }
      let url = null;
      try {
        url = await WPP.contact.getProfilePictureUrl(id) ?? null;
      } catch {
        url = null;
      }
      fotosPorId.set(id, url);
      saida[id] = url;
    }));
    return saida;
  },
  /** Foto do WhatsApp conectado (botão da conta na barra do topo). */
  async minhaFoto() {
    try {
      const eu = WPP.conn.getMyUserId?.()?._serialized;
      return eu ? await WPP.contact.getProfilePictureUrl(eu) ?? null : null;
    } catch {
      return null;
    }
  },
  async sendText({ texto }) {
    const chat = WPP.chat.getActiveChat();
    const alvo = chat?.id?._serialized;
    if (!alvo) throw new Error("Nenhuma conversa aberta.");
    await WPP.chat.sendTextMessage(alvo, texto, { createChat: true });
    return { ok: true };
  }
};
window.addEventListener("message", (ev) => {
  const msg = ev.data;
  if (!msg || msg.__advox !== "req") return;
  const fn = comandos[msg.cmd];
  if (!fn) {
    responder(msg.id, false, void 0, `Comando desconhecido: ${msg.cmd}`);
    return;
  }
  fn(msg.payload).then((data) => responder(msg.id, true, data)).catch((e) => responder(msg.id, false, void 0, e?.message ?? String(e)));
});
const ehMoment = (m) => !!m && typeof m.locale === "function" && typeof m.defineLocale === "function";
let momentAchado = null;
function acharMoment() {
  if (momentAchado) return momentAchado;
  const w = window;
  const carregar = (nome) => {
    try {
      return typeof w.importNamespace === "function" ? w.importNamespace(nome) : w.require?.(nome);
    } catch {
      return null;
    }
  };
  let candidatos = ["WAWebMoment", "moment"];
  try {
    const mapa = w.require?.("__debug")?.modulesMap ?? {};
    const doMapa = Object.keys(mapa).filter((n) => /moment/i.test(n) && !/moment-[a-z]/i.test(n));
    candidatos = [.../* @__PURE__ */ new Set([...candidatos, ...doMapa])];
  } catch {
  }
  for (const nome of candidatos) {
    const m = carregar(nome);
    const achado = ehMoment(m) ? m : ehMoment(m?.default) ? m.default : null;
    if (achado) {
      momentAchado = achado;
      break;
    }
  }
  return momentAchado;
}
function corrigirIdiomaDasDatas() {
  try {
    const moment = acharMoment();
    if (!moment) return false;
    if (!moment.__advoxTravado) {
      const original = moment.defineLocale.bind(moment);
      moment.defineLocale = (nome, cfg) => {
        const atual = moment.locale();
        const r = original(nome, cfg);
        if (moment.locale() !== atual) moment.locale(atual);
        return r;
      };
      moment.__advoxTravado = true;
    }
    const lang = (document.documentElement.lang || navigator.language || "pt-BR").toLowerCase();
    const disponiveis = moment.locales?.() ?? [];
    const alvo = [lang, lang.split("-")[0]].find((l) => disponiveis.includes(l));
    if (alvo && moment.locale() !== alvo) moment.locale(alvo);
    return true;
  } catch {
    return false;
  }
}
function marcarPronto() {
  if (pronto) return;
  pronto = true;
  emitir("ready");
  console.info("[Advox] WhatsApp pronto.");
  for (const ms of [0, 3e3, 1e4, 3e4]) setTimeout(corrigirIdiomaDasDatas, ms);
  try {
    WPP.on("chat.active_chat", (chat) => {
      const base = contatoDoChat(chat);
      emitir("active-chat", base);
      if (base && !base.telefone && !base.ehGrupo) {
        contatoCompleto(chat).then((c) => c?.telefone && emitir("active-chat", c));
      }
    });
  } catch {
  }
}
function iniciar() {
  WPP = window.WPP;
  if (!WPP) {
    setTimeout(iniciar, 100);
    return;
  }
  let tentativas = 0;
  const travar = setInterval(() => {
    if (corrigirIdiomaDasDatas() || ++tentativas > 120) clearInterval(travar);
  }, 500);
  try {
    const wp = WPP.webpack;
    if (wp?.injectLoader && !wp.isInjected) wp.injectLoader();
    wp?.onFullReady?.(marcarPronto);
  } catch {
  }
  try {
    WPP.on?.("conn.main_ready", marcarPronto);
  } catch {
  }
  const vigia = setInterval(() => {
    try {
      if (WPP.conn?.isMainReady?.()) {
        clearInterval(vigia);
        marcarPronto();
      }
    } catch {
    }
  }, 1e3);
}
iniciar();
